Place the directory containing these files into the ./<cml>/output directory, where <cml> is the root CML directory.
