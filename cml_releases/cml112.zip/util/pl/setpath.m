plroot = pwd;
src = [plroot '/src'];

addpath(plroot);
addpath(src);
