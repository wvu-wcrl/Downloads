% set figure x-y zoom
function setzoom(fhd,zoom)
figure(fhd);
axis(zoom);
end