
% read the location of CML's home
%load('CmlHome.mat');

CmlPrint('silent message', [], 'silent');

CmlPrint('verbose message', [], 'verbose');
